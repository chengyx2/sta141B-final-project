#! /usr/bin/env python3
# -*- coding: utf-8 -*-
# vim:fenc=utf-8
#
# Copyright © 2021 babyfan <ljyswzxhdtz@gmail.com>
#
# Distributed under terms of the MIT license.

"""

"""
import os
from pathlib import Path
import zipfile
import requests
import pandas as pd
from pandas_profiling import ProfileReport
import numpy as np
from datetime import datetime
import sqlalchemy as sqla

DATA_DIR = Path('../data/')


def extract_vaccination():
    zip_file_name = DATA_DIR / 'vaccination.zip'
    if not os.path.isfile(zip_file_name):
        res = requests.get(
            url='https://storage.googleapis.com/kaggle-data-sets/1113000/2306784/bundle/archive.zip?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=gcp-kaggle-com%40kaggle-161607.iam.gserviceaccount.com%2F20210606%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20210606T075204Z&X-Goog-Expires=259199&X-Goog-SignedHeaders=host&X-Goog-Signature=907f961742f530922a3d1ede569cf5d26ed9eeb02074297d83e11c05ff911a29e450b3f29dee5970467d0b53a8cbeb2b4c02d94594e1dcee71f6041fda1d3f827d71d5cd75dcc705ea4d07a9aa9bf61b6bd086708d041c7d74603c32951eee1aadc95874f63c8fb979bf934d82b324e11fdb60c079bdf32219f4c6c9d6c1f3694676e54a7258cf39baef3ec2c33b1abaa8f6236e012abf4c86d6c30cd39bcd8a89d2bd6f0bc48d3edbc98a53dddd6985e2832c64e32d684febec9ec5edac8f1d9889f03168f8e324579d0ca23b4504843832ee33c02f906692b41dd19ec80cf74428241e33783e3d9ea2e31d6f4095f682c6859352e77d57d06823cd71dfd997'
        )
        with open(zip_file_name, "wb") as f:
            f.write(res.content)
        azip = zipfile.ZipFile(zip_file_name)
        csv_files = azip.namelist()
        assert len(csv_files) == 1, 'zip file ERROR!'
        csv_name = azip.extract(csv_files[0], DATA_DIR)
        return csv_name
    else:
        return DATA_DIR / 'us_state_vaccinations.csv'


def extract_cases():
    cases_file = DATA_DIR / 'cases.csv'
    if not os.path.isfile(cases_file):
        res = requests.get(
            url='https://data.cdc.gov/api/views/9mfq-cb36/rows.csv?accessType=DOWNLOAD'
        )
        with open(cases_file, "wb") as f:
            f.write(res.content)
    return cases_file


def munging(case_df):
    case_df = case_df.sort_values(by=["submission_date", "state"])

    # date transformation
    case_df['submission_date'] = case_df['submission_date'].apply(
        lambda date_str: datetime.strptime(date_str, '%m/%d/%Y').__format__(
            '%Y-%m-%d'))

    # replace abbreviations with its full name
    state_name = [
        "Alabama", "AL", "Alaska", "AK", "Arizona", "AZ", "Arkansas", "AR",
        "California", "CA", "Colorado", "CO", "Connecticut", "CT", "Delaware",
        "DE", "Florida", "FL", "Georgia", "GA", "Hawaii", "HI", "Idaho", "ID",
        "Illinois", "IL", "Indiana", "IN", "Iowa", "IA", "Kansas", "KS",
        "Kentucky", "KY", "Louisiana", "LA", "Maine", "ME", "Maryland", "MD",
        "Massachusetts", "MA", "Michigan", "MI", "Minnesota", "MN", "Mississippi",
        "MS", "Missouri", "MO", "Montana", "MT", "Nebraska", "NE", "Nevada", "NV",
        "New Hampshire", "NH", "New Jersey", "NJ", "New Mexico", "NM", "New York",
        "NYC", "North Carolina", "NC", "North Dakota", "ND", "Ohio", "OH",
        "Oklahoma", "OK", "Oregon", "OR", "Pennsylvania", "PA", "Rhode Island",
        "RI", "South Carolina", "SC", "South Dakota", "SD", "Tennessee", "TN",
        "Texas", "TX", "Utah", "UT", "Vermont", "VT", "Virginia", "VA",
        "Washington", "WA", "West Virginia", "WV", "Wisconsin", "WI", "Wyoming",
        "WY"
    ]
    fullnames, abbreviations = state_name[0::2], state_name[1::2]
    abb_dict = {}
    for full_name, abbreviation in zip(fullnames, abbreviations):
        abb_dict[abbreviation] = full_name

    case_df['state'] = case_df['state'].apply(
        lambda abbr: abb_dict.get(abbr, abbr))
    case_df = case_df[[
        "submission_date", "state", "tot_cases", "tot_death", "new_case"
    ]]

    # rename the columns
    case_df = case_df.rename(columns={
        'submission_date': 'date',
        'state': 'location'
    })
    return case_df


TABLE = 'DATE'
engine = sqla.create_engine('sqlite:///' + str(DATA_DIR / 'covid.sqlite'))


def data_storge(df, TABLE, engine):
    df.to_sql(name=TABLE, con=engine, if_exists='replace', index=False)
